import java.awt.BorderLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;


import net.miginfocom.swing.MigLayout;

public class Calculator extends JFrame {

	double number1;
	double number2;
	double number3;
	double number4;
	double number5;
	double number6;
	double number7;
	double number8;
	double number9;
	double number0;

	double result; 
	// Adding the base of the calculator
	private JPanel p1;

	// Adding the text display at the top of the calculator
	private JTextField t1;

	// Adding the basic calculator buttons
	private JButton b1, b2, b3, b4, b5, b6, b7, b8, b9, b0, bPoint, bEqual, bMinus, bPlus, bMulti, bDiv, bClear,
			bClearDis, bBack;

	// Adding the bonus calculator buttons
	private JButton bMc, bMr, bMs, bMPlus, bMMinus, bPlusMinus, bRoot, bPercent, bPower, bInverse;

	public Calculator() {		
		CalculatorGUI();
	}

	public void CalculatorGUI() {

		// Making the panel
		JPanel p1 = new JPanel();
		p1.setLayout(new MigLayout());

		JTextField t1 = new JTextField("");
		t1.setEditable(false);
		t1.setHorizontalAlignment(JTextField.RIGHT);

		
		
		
		// Giving my buttons inputs
		b1 = new JButton("1");
		b2 = new JButton("2");
		b3 = new JButton("3");
		b4 = new JButton("4");
		b5 = new JButton("5");
		b6 = new JButton("6");
		b7 = new JButton("7");
		b8 = new JButton("8");
		b9 = new JButton("9");
		b0 = new JButton("0");

		bPoint = new JButton(".");
		bEqual = new JButton("=");
		bMinus = new JButton("-");
		bPlus = new JButton("+");
		bMulti = new JButton("*");
		bDiv = new JButton("/");
		bClear = new JButton("C");
		bClearDis = new JButton("CE");
		bBack = new JButton("<-");

		bMc = new JButton("MC");
		bMr = new JButton("MR");
		bMs = new JButton("MS");
		bMPlus = new JButton("M+");
		bMMinus = new JButton("M-");
		bPlusMinus = new JButton("\u00B1");
		bRoot = new JButton("\u221A");
		bPercent = new JButton("%");
		bPower = new JButton("^");
		bInverse = new JButton("1/2");
		
        p1.add(t1, "spanx, wrap");
		
		//Row One
		p1.add(bMc, "grow");
		p1.add(bMr, "grow");
		p1.add(bMs, "grow");
		p1.add(bMPlus, "grow");
		p1.add(bMMinus, "wrap");
		
		//Second Row
		p1.add(bBack, "grow");
		p1.add(bClear, "grow");
		p1.add(bClearDis, "grow");
		p1.add(bPlusMinus, "grow");
		p1.add(bRoot, "wrap");
		
		//Third Row
		p1.add(b7, "grow");
		p1.add(b8, "grow");
		p1.add(b9, "grow");
		p1.add(bDiv, "grow");
		p1.add(bPercent, "wrap");
		
		//Fourth Row
		p1.add(b4, "grow");
		p1.add(b5, "grow");
		p1.add(b6, "grow");
		p1.add(bMulti, "grow");
		p1.add(bPower, "wrap");
		
		//Fifth Row
		p1.add(b1, "grow");
		p1.add(b2, "grow");
		p1.add(b3, "grow");
		p1.add(bMinus, "grow");
		p1.add(bInverse, "wrap");
		
		//Sixth Row
		p1.add(b0, "grow, span 2");
		p1.add(bPoint, "grow");
		p1.add(bPlus, "grow");
		p1.add(bEqual, "grow");
		
		add(p1, BorderLayout.CENTER);		
		setTitle("Calculator");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(350, 350);
		setVisible(true);

		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + b1.getText();
				t1.setText(enterNumber);
			}
		});

		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + b2.getText();
				t1.setText(enterNumber);
			}
		});

		b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + b3.getText();
				t1.setText(enterNumber);
			}
		});

		b4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + b4.getText();
				t1.setText(enterNumber);
			}
		});

		b5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + b5.getText();
				t1.setText(enterNumber);
			}
		});

		b6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + b6.getText();
				t1.setText(enterNumber);
			}
		});

		b7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + b7.getText();
				t1.setText(enterNumber);
			}
		});

		b8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + b8.getText();
				t1.setText(enterNumber);
			}
		});

		b9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + b9.getText();
				t1.setText(enterNumber);
			}
		});

		b0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + b0.getText();
				t1.setText(enterNumber);
			}
		});

		bPoint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + bPoint.getText();
				t1.setText(enterNumber);
			}
		});

		bEqual.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + bEqual.getText();
				t1.setText(enterNumber);
			}
		});

		bMinus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + bMinus.getText();
				t1.setText(enterNumber);
			}
		});

		bPlus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + bPlus.getText();
				t1.setText(enterNumber);
			}
		});

		bMulti.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + bMulti.getText();
				t1.setText(enterNumber);
			}
		});

		bClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + bClear.getText();
				t1.setText(enterNumber);
			}
		});

		bClearDis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + bClearDis.getText();
				t1.setText(enterNumber);
			}
		});

		bBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + bBack.getText();
				t1.setText(enterNumber);
			}
		});

		bMc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + bMc.getText();
				t1.setText(enterNumber);
			}
		});

		bMr.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + bMr.getText();
				t1.setText(enterNumber);
			}
		});

		bMs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + bMs.getText();
				t1.setText(enterNumber);
			}
		});

		bMPlus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + bMPlus.getText();
				t1.setText(enterNumber);
			}
		});

		bMMinus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + bMMinus.getText();
				t1.setText(enterNumber);
			}
		});

		bPlusMinus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + bPlusMinus.getText();
				t1.setText(enterNumber);
			}
		});

		bRoot.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + bRoot.getText();
				t1.setText(enterNumber);
			}
		});

		bPercent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + bPercent.getText();
				t1.setText(enterNumber);
			}
		});

		bPower.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + bPower.getText();
				t1.setText(enterNumber);
			}
		});

		bInverse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enterNumber = t1.getText() + bInverse.getText();
				t1.setText(enterNumber);
			}
		});
	}

	public static void main(String[] args) {
		 new Calculator();
	}
}
